
<div id="sidebar" class="hidden-xs" >		

			<div class="sidebox">	
			
				<h1 class="clear">I am sidebar</h1>

					
		</div>
		</div>
