=== ThemeIsle Companion ===
Contributors: themeisle, codeinwp, rodicaelena, baicusandrei
Tags: widget, admin, widgets
Requires at least: 3.0
Tested up to: 4.7.2
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Enhances ThemeIsle's themes with extra functionalities.

== Description ==

Enhances ThemeIsle's themes with extra functionalities.

== Changelog ==

= 1.0.3 =

* New widgets for Rhea child theme
* Improved front page selection mechanism for Hestia

= 1.0.1 = 

* Changed tested up to

= 1.0.0 =

* First version of the plugin
