    <!-- footer -->
    <div class="container-fluid footer">
        <p>ST. JUDE'S ANGLICAN CHURCH CARLTON, 2 KEPPEL ST, CARLTON, VIC, 3053 AUSTRALIA </br> AUSSIEPRAYER@GMAIL.COM</p>
        </br>
        <p>FOLLOW US on FACEBOOK</p>
        </br>
        <div class="footer_fb">
            <iframe src="https://www.facebook.com/plugins/follow.php?href=https%3A%2F%2Fwww.facebook.com%2Fcrosscultures.melbourne%2F&width=80&height=65&layout=button&size=large&show_faces=false&appId" width="80" height="65" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
        </div>
        <div class='footer_link'>
            <div><a href="<?php echo get_option('home'); ?>/about-us/">ABOUT US</a></div>
            <div><a href="<?php echo get_option('home'); ?>/contact-us/">CONTACT US</a></div>
            <div><a href="<?php echo get_option('home'); ?>/partner-sites/">PARTNER SITES</a></div>
            <div><a href="<?php echo get_option('home'); ?>/useful-websites/">USEFUL LINKS</a></div>   
        </div>
        
        <div class='footer_policy'><a href="">Privacy Policy</a></div>
        <ul class="transBox2"><?php pll_the_languages(array('show_flags'=>1,'show_names'=>0)); ?></ul>
    </div>
    <img src="<?php echo get_template_directory_uri();?>/images/crossculture-logo.png" class="img-responsive" style="display:none">
    <?php wp_footer(); ?>
</body>

</html>

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="<?php echo get_template_directory_uri();?>/lib/js/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<!-- <script src="<?php echo get_template_directory_uri();?>/lib/js/bootstrap.min.js"></script> -->
<script>
    $("img")
  .error(function(){
    $(this).hide();
  })
</script>