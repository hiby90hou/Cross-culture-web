
<div id="sidebar" class="hidden-xs" >		

	<div class="sidebox">	
	
		<h1 class="clear">New blog</h1>
		<ul class="sidemenu">
			<?php wp_get_archives('type=postbypost&limit=5'); ?>
		</ul>
	</div>
			
			<div class="sidebox">	
			
				<h1>Partner Sites</h1>
				<ul class="sidemenu">
					<li><a href="http://stjudesunichurch.com/" class="top">Uni Church</a></li>
					<li><a href="http://www.melbourne.cu.org.au/">Christian Union at Melbourne University</a></li>
					<li><a href="https://www.afes.org.au/">AFES</a></li>	

				</ul>				
			</div>

			<div class="sidebox">	
			
				<h1>Other Focus Group</h1>
				<ul class="sidemenu">
					<li><a href="http://www.focus.asn.au/international" class="top">Australian National University</a></li>
					<li><a href="http://www.focus.asn.au/international"> University of Canberra</a></li>		
					<li><a href="http://www.christianunion.org.au/"> Macquarie University</a></li>
					<li><a href="http://www.newcastlechristianstudents.org"> Newcastle University</a></li>
					<li><a href="http://sueu.org.au">Sydney University</a></li>
					<li><a href="http://credo.org.au">University of Technology Sydney</a></li>
					<li><a href="https://clubs.uow.edu.au/clubs/evangelical-christian-union-ecu-/focus/">University of Wollongong</a></li>
					<li><a href="http://focus-unsw.org/">University of New South Wales</a></li>
					<li><a href="http://www.portmacquariechristianstudents.org.au/">Port Macquarie</a></li>
					<li><a href="http://cujcu.com.au">James Cook University</a></li>
					<li><a href="http://www.qutchristians.info">Queensland University of Technology</a></li>
					<li><a href="http://uqes.org.au/">University of Queensland</a></li>
					<li><a href="http://focusadelaide.org.au/">Adelaide University</a></li>
					<li><a href="focustas.org">University of Tasmania</a></li>
					<li><a href="http://claytoncu.org/">Monash University</a></li>
					<li><a href="http://rmit.cu.org.au">RMIT</a></li>
					<li><a href="http://www.swinburnecu.org">Swinburne University</a></li>
					<li><a href="http://latrobe.cu.org.au/index.php?page=international-students">La Trobe University</a></li>
					<li><a href="http://www.deakin.cu.org.au">Deakin University (Burwood)</a></li>
					<li><a href="http://geelong.cu.org.au">Deakin University (Geelong)</a></li>
					<li><a href="http://www.uwacu.org/">University of Western Australia</a></li>
					<li><a href="http://www.ccu.org.au/">Curtin University</a></li>
				</ul>				
			</div>
</div>
